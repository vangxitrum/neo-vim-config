vim.keymap.set('n', '<leader>ps', '<Cmd>:Telescope lsp_document_symbols<CR>')
